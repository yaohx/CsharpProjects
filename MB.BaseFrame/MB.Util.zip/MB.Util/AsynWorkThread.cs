﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MB.Util {
    /// <summary>
    /// 提供异步调用的后台工作线程。
    /// </summary>
    [System.ComponentModel.ToolboxItem(false)]
    public class AsynWorkThread : System.ComponentModel.BackgroundWorker {
        /// <summary>
        /// 提供异步调用的后台工作线程。
        /// </summary>
        public AsynWorkThread() {

        }
    }
}
