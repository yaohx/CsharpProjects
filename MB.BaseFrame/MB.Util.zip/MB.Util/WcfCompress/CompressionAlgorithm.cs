﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MB.Util.WcfCompress
{
    public enum CompressionAlgorithm
    {
        GZip,
        Deflate
    }
}
